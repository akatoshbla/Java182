/**
* Project #3: A Curious or Hungry Robot
* File: Memory.java
* Programmers: David Kopp
* Date: 12/8/13
* Description: This program 
**/

import java.awt.Point;
import java.util.Random;

public class Robot {

private int robotEnergy;
private Point robotPosition;

public Robot(Point pos, int energy) {
robotPosition = pos;
robotEnergy = energy;

}

public Point getPos() {
return robotPosition;

}

public int getEnergy() {
return robotEnergy;

}

public void setRobotPos(Point pos) {
robotPosition = pos;

}

public void setRobotEnergy(int energy) {
robotEnergy = energy;

}

public void memStructureSelector(Point aPoint, int enable) {
switch (enable) {
case 1: ClosesFirstStructure mem1 = new ClosesFirstStructure(aPoint);
break;  

case 2: RandomStructure mem2 = new RandomStructure(aPoint); 
break;

case 3: FifoStructure mem3 = new FifoStructure(aPoint);
break;

case 4: LifoStructure mem4 = new LifoStructure(aPoint);
break;

}
}

public Point curiousState(Point current) {
Random random = new Random();
int x = random.nextInt(14) - 7;
int y = random.nextInt(14) - 7;

Point move = new Point((int)current.getX() + x, (int)current.getY() + y);

if (move.getX() > 200 || move.getY() > 200 || move.getX() < 0 || move.getY() < 0 ) {
curiousState(current);

}

else { }  

return move;

}

public Point hungryState(Point pos) {


return new Point(0, 0);

}

public void inactiveState(double dist) {
System.out.println("The robot has no more energy and is inactive and traveled " + dist);

}

}