/**
* Project #3: A Curious or Hungry Robot
* File: Memory.java
* Programmers: David Kopp
* Date: 12/8/13
* Description: This program 
**/

import java.util.ArrayList;
import java.util.Random;
import java.awt.Point;

public class RobotSim {
ArrayList<EnergyNode> eList = new ArrayList<EnergyNode>();
Random random = new Random();
double totalDistance = 0;
Point movePoint;
int step = 0;
boolean roboHasEnergy = true;

public RobotSim(int numberNodes, int nodeEnergy, int roboEnergy) {
while (eList.size() <= numberNodes) {
addEnergyNode(nodeEnergy);

}

// for (int i = 0; i < eList.size(); i++) {
// System.out.println(eList.get(i));
// 
// }

Point roboStart = new Point(random.nextInt(200), random.nextInt(200));
Robot robo = new Robot(roboStart, roboEnergy);
System.out.println("Robot's Position: " + robo.getPos() + ", Robot's Energy: " + robo.getEnergy());

while (roboHasEnergy == true) {
if (robo.getEnergy() > 50) {
movePoint = robo.curiousState(roboStart);
totalDistance += distTraveled(roboStart, movePoint);
robo.setRobotEnergy(robo.getEnergy() - (int)distTraveled(roboStart, movePoint));
robo.setRobotPos(movePoint);
roboStart = movePoint;
step += 1;
System.out.println("Step " + step +  " :" + "Robot's Position: " + robo.getPos() + ", Robot's Energy: " + robo.getEnergy());

}

else if (robo.getEnergy() <= 50 && robo.getEnergy() >= 0) {
movePoint = robo.hungryState(roboStart);
totalDistance += distTraveled(roboStart, movePoint);
robo.setRobotEnergy(robo.getEnergy() - (int)distTraveled(roboStart, movePoint));
robo.setRobotPos(movePoint);
roboStart = movePoint;
step += 1;
System.out.println("Step " + step +  " :" + "Robot's Position: " + robo.getPos() + ", Robot's Energy: " + robo.getEnergy());

}

else {
roboHasEnergy = false;
robo.inactiveState(totalDistance);
step += 1;

}
}
}

public double distTraveled(Point p1, Point p2) {
double result = 0;
result = p1.distance(p2);
return result; 

}

public void addEnergyNode(int eLvl) {
EnergyNode temp = new EnergyNode(random.nextInt(200), random.nextInt(200), eLvl);
boolean result = true;

for (int i = 0; i < eList.size(); i++) {
if (temp.getEnergyLocation().distance(eList.get(i).getEnergyLocation()) < 20) {
result = false;

}
}

if (result == true) {
eList.add(temp);

}
}

public static void main(String[] args) { 
RobotSim sim = new RobotSim(40, 125, 100);

}

}