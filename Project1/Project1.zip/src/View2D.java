/**
* Project #1: Polymorphism and Inheritance
* File: View2d.java
* Programmers: Roland Avdalyan and David Kopp
* Date: 8/28/13
* Description: This program reads a text file and creates an array of objects. Each object is then created by this main file calling the corresponding 
* 					constructors. Each object is then read and drawn by an iterator.
*/

   import java.awt.*;
   import java.util.*;
   import java.io.*;

   public class View2D extends Window182 {
   
      private ArrayList<DrawableShape> scene = new ArrayList<DrawableShape>();
   
      public View2D(String title, String fileName) {
      
      // Defined variables and super import
         super(title);
         int red, green, blue, x, y, width, height, numberStrings;
         File input = new File(fileName);
         String name = null;
      
      // Try and Catch for opening input file
         try {
            Scanner inFile = new Scanner(input);
         
         // While loop that reads the name of the object that needs to be created and put into an array
            while (inFile.hasNext()){
               name = inFile.next();
               System.out.println(name);
            	
            	// This if loop takes both box or oval and sets the corresponding object into an array
               if (name.equalsIgnoreCase("Box") || name.equalsIgnoreCase("Oval")) {
                  red = inFile.nextInt();
                  green = inFile.nextInt();
                  blue = inFile.nextInt();
                  x = inFile.nextInt();
                  y = inFile.nextInt();
                  width = inFile.nextInt();
                  height = inFile.nextInt();
                  Color shapeColor = new Color(red, green, blue);
                  System.out.println("Color RGB: " + shapeColor + " X: " + x + " Y: " + y + " Width: " + width + " Height " + height);
               	
               // This nested if loop creates a box object
                  if (name.equalsIgnoreCase("Box")) {
                     scene.add(new Box(shapeColor, x, y, width, height));
                  }
               
               // This nested if loop creates a oval object
                  if (name.equalsIgnoreCase("Oval")) {
                     scene.add(new Oval(shapeColor, x, y, width, height));
                  }
               
               }
            
            // This if loop creates a text object and adds them to an array
               if (name.equalsIgnoreCase("Text")) {
                  x = inFile.nextInt();
                  y = inFile.nextInt();
                  numberStrings = inFile.nextInt();
                  String n = "";
               
               // This for loop allows the number of strings to be combined into a larger string
                  for(int i = 0; i < numberStrings; i++) {
                     n.concat(inFile.next());
                  
                  }
               
                  scene.add(new Text(x, y, n));
               
               }
            
            }
         
         	
            inFile.close();
				
         }
         
            catch (FileNotFoundException e){
               System.out.println("File not found, try again");
            }
      	
        //  repaint();
      }	
   
   // This is the paint call to the iterator with a while loop to draw each shape
      public void paint(Graphics g){
         Iterator<DrawableShape> iterator = scene.iterator();
      	super.paint(g);
			
         while(iterator.hasNext()){
            DrawableShape shape = iterator.next();
            shape.draw(g);
         }	
			
      	repaint();
      }
   
   // This is the main method that starts the chain of calls to create a array and draw the objects in that array to a Frame.
      public static void main(String [] arg){
         View2D vw = new View2D("Roland Avdalyan and David Kopp", "scene.v2d");
			
      }
   	
   }